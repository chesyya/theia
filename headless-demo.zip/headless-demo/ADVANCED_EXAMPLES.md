# 无头插件高级示例

本文档展示无头插件的高级使用场景和最佳实践。

## 示例 1：数据库连接池管理

```javascript
// headless.js
const mysql = require('mysql2/promise');

let connectionPool = null;

async function activate() {
    console.log('[DB Pool] 初始化数据库连接池...');

    // 创建连接池 - 所有前端共享
    connectionPool = mysql.createPool({
        host: process.env.DB_HOST || 'localhost',
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME || 'myapp',
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0
    });

    console.log('[DB Pool] 连接池已创建，最大连接数: 10');

    // 暴露查询接口供其他服务使用
    return {
        query: async (sql, params) => {
            const [rows] = await connectionPool.execute(sql, params);
            return rows;
        },
        getStats: () => ({
            active: connectionPool._allConnections.length,
            idle: connectionPool._freeConnections.length
        })
    };
}

function deactivate() {
    if (connectionPool) {
        console.log('[DB Pool] 关闭连接池...');
        connectionPool.end();
    }
}

module.exports = { activate, deactivate };
```

## 示例 2：缓存服务

```javascript
// headless.js
const Redis = require('ioredis');

let redisClient = null;
const localCache = new Map();

async function activate() {
    console.log('[Cache] 初始化缓存服务...');

    // 尝试连接 Redis
    try {
        redisClient = new Redis({
            host: process.env.REDIS_HOST || 'localhost',
            port: process.env.REDIS_PORT || 6379,
            retryStrategy: (times) => {
                if (times > 3) {
                    console.warn('[Cache] Redis 连接失败，使用内存缓存');
                    return null;
                }
                return Math.min(times * 100, 2000);
            }
        });

        redisClient.on('ready', () => {
            console.log('[Cache] Redis 连接成功');
        });

        redisClient.on('error', (err) => {
            console.error('[Cache] Redis 错误:', err.message);
        });
    } catch (error) {
        console.warn('[Cache] Redis 不可用，使用内存缓存');
    }

    // 返回缓存 API
    return {
        async get(key) {
            if (redisClient && redisClient.status === 'ready') {
                return await redisClient.get(key);
            }
            return localCache.get(key);
        },

        async set(key, value, ttl = 3600) {
            if (redisClient && redisClient.status === 'ready') {
                await redisClient.setex(key, ttl, value);
            } else {
                localCache.set(key, value);
                // 简单的 TTL 实现
                setTimeout(() => localCache.delete(key), ttl * 1000);
            }
        },

        async del(key) {
            if (redisClient && redisClient.status === 'ready') {
                await redisClient.del(key);
            }
            localCache.delete(key);
        },

        getStats() {
            return {
                type: redisClient?.status === 'ready' ? 'redis' : 'memory',
                size: localCache.size
            };
        }
    };
}

function deactivate() {
    if (redisClient) {
        console.log('[Cache] 关闭 Redis 连接...');
        redisClient.quit();
    }
    localCache.clear();
}

module.exports = { activate, deactivate };
```

## 示例 3：定时任务调度器

```javascript
// headless.js
const cron = require('node-cron');

const jobs = new Map();

function activate() {
    console.log('[Scheduler] 初始化任务调度器...');

    // 示例：每天凌晨 2 点清理临时文件
    const cleanupJob = cron.schedule('0 2 * * *', () => {
        console.log('[Scheduler] 执行清理任务...');
        // 清理逻辑
    }, {
        scheduled: false
    });
    jobs.set('cleanup', cleanupJob);

    // 示例：每 5 分钟检查系统状态
    const healthCheckJob = cron.schedule('*/5 * * * *', () => {
        console.log('[Scheduler] 执行健康检查...');
        // 健康检查逻辑
    }, {
        scheduled: false
    });
    jobs.set('healthCheck', healthCheckJob);

    // 启动所有任务
    jobs.forEach(job => job.start());
    console.log(`[Scheduler] ${jobs.size} 个定时任务已启动`);

    return {
        addJob(name, cronExpression, callback) {
            const job = cron.schedule(cronExpression, callback);
            jobs.set(name, job);
            job.start();
            console.log(`[Scheduler] 添加任务: ${name}`);
        },

        removeJob(name) {
            const job = jobs.get(name);
            if (job) {
                job.stop();
                jobs.delete(name);
                console.log(`[Scheduler] 移除任务: ${name}`);
            }
        },

        getJobs() {
            return Array.from(jobs.keys());
        }
    };
}

function deactivate() {
    console.log('[Scheduler] 停止所有定时任务...');
    jobs.forEach((job, name) => {
        job.stop();
        console.log(`[Scheduler] 已停止: ${name}`);
    });
    jobs.clear();
}

module.exports = { activate, deactivate };
```

## 示例 4：文件监控服务

```javascript
// headless.js
const chokidar = require('chokidar');
const path = require('path');

let watchers = [];
const listeners = [];

function activate() {
    console.log('[FileWatcher] 初始化文件监控服务...');

    // 监控工作区配置文件
    const configWatcher = chokidar.watch('**/.theia/*.json', {
        ignored: /(^|[\/\\])\../,
        persistent: true,
        ignoreInitial: true
    });

    configWatcher
        .on('add', filePath => notifyListeners('add', filePath))
        .on('change', filePath => notifyListeners('change', filePath))
        .on('unlink', filePath => notifyListeners('unlink', filePath));

    watchers.push(configWatcher);

    console.log('[FileWatcher] 监控已启动');

    return {
        watch(pattern, callback) {
            const watcher = chokidar.watch(pattern, {
                ignored: /(^|[\/\\])\../,
                persistent: true
            });

            watcher.on('all', (event, path) => {
                callback(event, path);
            });

            watchers.push(watcher);
            return () => {
                watcher.close();
                watchers = watchers.filter(w => w !== watcher);
            };
        },

        onFileChange(callback) {
            listeners.push(callback);
            return () => {
                const index = listeners.indexOf(callback);
                if (index > -1) listeners.splice(index, 1);
            };
        }
    };
}

function notifyListeners(event, filePath) {
    console.log(`[FileWatcher] ${event}: ${filePath}`);
    listeners.forEach(listener => {
        try {
            listener(event, filePath);
        } catch (error) {
            console.error('[FileWatcher] 监听器错误:', error);
        }
    });
}

function deactivate() {
    console.log('[FileWatcher] 停止文件监控...');
    watchers.forEach(watcher => watcher.close());
    watchers = [];
    listeners.length = 0;
}

module.exports = { activate, deactivate };
```

## 示例 5：WebSocket 服务器

```javascript
// headless.js
const WebSocket = require('ws');

let wss = null;
const clients = new Set();

function activate() {
    console.log('[WebSocket] 启动 WebSocket 服务器...');

    const port = process.env.WS_PORT || 8080;
    wss = new WebSocket.Server({ port });

    wss.on('connection', (ws, req) => {
        const clientId = `${req.socket.remoteAddress}:${req.socket.remotePort}`;
        console.log(`[WebSocket] 新连接: ${clientId}`);
        clients.add(ws);

        ws.on('message', (message) => {
            console.log(`[WebSocket] 收到消息: ${message}`);
            // 广播给所有客户端
            broadcast(message.toString());
        });

        ws.on('close', () => {
            console.log(`[WebSocket] 连接关闭: ${clientId}`);
            clients.delete(ws);
        });

        ws.on('error', (error) => {
            console.error(`[WebSocket] 错误: ${error.message}`);
        });

        // 发送欢迎消息
        ws.send(JSON.stringify({
            type: 'welcome',
            message: 'Connected to Theia headless plugin',
            timestamp: Date.now()
        }));
    });

    console.log(`[WebSocket] 服务器运行在端口 ${port}`);

    return {
        broadcast(message) {
            broadcast(message);
        },

        send(clientIndex, message) {
            const client = Array.from(clients)[clientIndex];
            if (client && client.readyState === WebSocket.OPEN) {
                client.send(message);
            }
        },

        getClientCount() {
            return clients.size;
        }
    };
}

function broadcast(message) {
    const data = typeof message === 'string' ? message : JSON.stringify(message);
    clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(data);
        }
    });
}

function deactivate() {
    console.log('[WebSocket] 关闭 WebSocket 服务器...');
    clients.forEach(client => client.close());
    if (wss) {
        wss.close();
    }
}

module.exports = { activate, deactivate };
```

## 示例 6：许可证管理器

```javascript
// headless.js
const crypto = require('crypto');

let licenseInfo = null;
const activatedClients = new Map();

function activate() {
    console.log('[License] 初始化许可证管理器...');

    // 验证许可证
    licenseInfo = validateLicense();

    if (!licenseInfo.valid) {
        console.error('[License] 许可证无效！');
        throw new Error('Invalid license');
    }

    console.log(`[License] 许可证有效，最大用户数: ${licenseInfo.maxUsers}`);

    // 定期检查许可证
    const checkInterval = setInterval(() => {
        const info = validateLicense();
        if (!info.valid) {
            console.error('[License] 许可证已过期！');
            // 可以触发警告或限制功能
        }
    }, 3600000); // 每小时检查一次

    return {
        canActivate() {
            return activatedClients.size < licenseInfo.maxUsers;
        },

        activate(userId) {
            if (activatedClients.size >= licenseInfo.maxUsers) {
                throw new Error('License limit reached');
            }
            activatedClients.set(userId, Date.now());
            console.log(`[License] 用户激活: ${userId}, 当前: ${activatedClients.size}/${licenseInfo.maxUsers}`);
        },

        deactivate(userId) {
            activatedClients.delete(userId);
            console.log(`[License] 用户注销: ${userId}`);
        },

        getInfo() {
            return {
                ...licenseInfo,
                activeUsers: activatedClients.size
            };
        },

        cleanup: () => clearInterval(checkInterval)
    };
}

function validateLicense() {
    // 这里是示例，实际应该从文件或服务器读取
    const licenseKey = process.env.LICENSE_KEY || 'demo-license';

    // 简单的许可证验证逻辑
    return {
        valid: true,
        maxUsers: 10,
        expiryDate: new Date('2026-12-31'),
        features: ['ide', 'debug', 'git']
    };
}

function deactivate() {
    console.log('[License] 清理许可证管理器...');
    activatedClients.clear();
}

module.exports = { activate, deactivate };
```

## 最佳实践

### 1. 错误处理

```javascript
async function activate() {
    try {
        // 初始化逻辑
        await initializeService();
    } catch (error) {
        console.error('[Plugin] 初始化失败:', error);
        // 降级处理
        return getFallbackAPI();
    }
}
```

### 2. 优雅关闭

```javascript
function deactivate() {
    return new Promise((resolve) => {
        // 停止接受新请求
        stopAcceptingRequests();

        // 等待现有请求完成
        waitForPendingRequests()
            .then(() => {
                // 清理资源
                cleanup();
                resolve();
            })
            .catch(error => {
                console.error('[Plugin] 清理错误:', error);
                resolve(); // 即使出错也要 resolve
            });
    });
}
```

### 3. 资源监控

```javascript
function activate() {
    // 定期报告资源使用
    setInterval(() => {
        const usage = process.memoryUsage();
        console.log('[Plugin] 内存使用:', {
            rss: Math.round(usage.rss / 1024 / 1024) + 'MB',
            heapUsed: Math.round(usage.heapUsed / 1024 / 1024) + 'MB'
        });
    }, 60000);
}
```

### 4. 配置管理

```javascript
const config = {
    dbHost: process.env.DB_HOST || 'localhost',
    dbPort: parseInt(process.env.DB_PORT || '3306'),
    cacheEnabled: process.env.CACHE_ENABLED === 'true',
    logLevel: process.env.LOG_LEVEL || 'info'
};

function activate() {
    console.log('[Plugin] 配置:', config);
    // 使用配置初始化
}
```

## 注意事项

1. **内存管理**：确保定时器、监听器等资源在 deactivate 中正确清理
2. **错误隔离**：一个错误不应影响整个后端进程
3. **日志规范**：使用统一的日志前缀，方便调试
4. **异步处理**：activate 可以返回 Promise，确保异步初始化完成
5. **API 版本控制**：如果暴露 API，考虑版本兼容性

## 性能优化

1. **懒加载**：只在需要时加载依赖
2. **连接池**：复用数据库连接等资源
3. **缓存**：合理使用缓存减少重复计算
4. **批处理**：合并相似的请求
5. **监控**：定期输出性能指标

## 调试技巧

```javascript
// 启用调试日志
const DEBUG = process.env.PLUGIN_DEBUG === 'true';

function debug(...args) {
    if (DEBUG) {
        console.log('[Plugin][DEBUG]', ...args);
    }
}
```

然后启动时设置环境变量：
```bash
PLUGIN_DEBUG=true yarn start
```
