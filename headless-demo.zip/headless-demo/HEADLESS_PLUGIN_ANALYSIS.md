# 无头插件深度解析

## 一、核心本质

### 无头插件是什么？
**无头插件 = 纯后端单例插件**，具有以下核心特征：
- ✅ 只有后端代码，零前端UI
- ✅ 整个 Theia 后端实例只启动**一个插件宿主进程**
- ✅ 所有前端IDE连接**共享同一个插件实例**
- ✅ Main端代码运行在 **Node.js 后端环境**（不是浏览器）

### 关键代码证据
```typescript
// packages/plugin-ext-headless/src/hosted/node/plugin-host-headless-rpc.ts:56-59
protected createAPIFactory(_extInterfaces: HeadlessExtInterfaces): null {
    // As yet there is no default API namespace for backend plugins to access the Theia framework
    return null;  // ⚠️ 重点：无头插件没有默认API！
}
```

---

## 二、与普通插件的对比

| 维度 | 普通插件（VS Code/Theia Plugin） | 无头插件（Headless Plugin） |
|------|--------------------------------|---------------------------|
| **运行位置** | 前端(WebWorker) + 后端(Node) | 仅后端(Node) |
| **实例数量** | 每个前端连接一个实例 | 整个后端一个实例 |
| **生命周期** | 绑定到前端连接 | 绑定到后端进程 |
| **默认API** | ✅ 有 `vscode` 或 `theia` API | ❌ **没有默认API** |
| **UI扩展** | ✅ 支持（菜单/命令/视图等） | ❌ 不支持 |
| **激活事件** | 丰富（onCommand/onLanguage等） | 仅 `*` 和 `onStartupFinished` |
| **Main端环境** | 浏览器 | Node.js 后端 |
| **通信方式** | RPC (通过后端中转) | RPC (直连后端) |
| **配置字段** | `main` 或 `theiaPlugin.backend` | `theiaPlugin.headless` |

### 架构对比图

**普通插件（per-frontend）**
```
前端1 ──RPC──> 后端 ──> 插件宿主进程1
前端2 ──RPC──> 后端 ──> 插件宿主进程2
前端3 ──RPC──> 后端 ──> 插件宿主进程3
```

**无头插件（single backend）**
```
前端1 ──┐
前端2 ──┼──RPC──> 后端 ──> 插件宿主进程（唯一）
前端3 ──┘
```

---

## 三、能力与限制

### ✅ 无头插件能做什么

1. **后端服务管理**
   - 数据库连接池（所有前端共享）
   - Redis/缓存连接
   - 消息队列连接
   - WebSocket服务器

2. **定时任务**
   - Cron任务调度
   - 后台数据同步
   - 定期清理

3. **文件系统监控**
   - 监控项目文件变化
   - 日志收集

4. **全局状态管理**
   - 许可证管理
   - 用户会话跟踪
   - 全局配置

5. **访问Node.js模块**
   ```javascript
   const fs = require('fs');
   const mysql = require('mysql2');
   const redis = require('redis');
   // 所有Node.js模块都可用
   ```

### ❌ 无头插件不能做什么

1. **无法使用 vscode/theia API**
   ```javascript
   // ❌ 这些都不可用！
   const vscode = require('vscode');  // undefined!
   vscode.window.showInformationMessage();  // 报错
   vscode.commands.registerCommand();  // 报错
   ```

   **原因**：`createAPIFactory` 返回 `null`，没有注册这些API模块

2. **无法扩展UI**
   - 不能注册命令
   - 不能添加菜单项
   - 不能创建视图
   - 不能操作编辑器

3. **激活事件受限**
   ```json
   // ✅ 只能用这两个
   "activationEvents": ["*", "onStartupFinished"]

   // ❌ 这些都不支持
   "activationEvents": ["onCommand:xxx", "onLanguage:python", ...]
   ```

4. **无贡献点（Contribution Points）**
   ```json
   // ❌ 这些配置无效
   "contributes": {
     "commands": [...],    // 无效
     "menus": [...],       // 无效
     "views": [...]        // 无效
   }
   ```

---

## 四、配置差异详解

### 普通插件配置
```json
{
  "name": "my-plugin",
  "engines": { "vscode": "^1.84.0" },
  "main": "./extension.js",        // 前端/后端入口
  "activationEvents": [
    "onCommand:myCommand",
    "onLanguage:javascript"
  ],
  "contributes": {
    "commands": [{...}],
    "menus": {...}
  }
}
```

### 无头插件配置
```json
{
  "name": "my-headless-plugin",
  "engines": { "vscode": "^1.84.0" },
  "theiaPlugin": {
    "headless": "headless"           // 指向无头入口
  },
  "headless": {
    "activationEvents": ["*"],       // 只能是 * 或 onStartupFinished
    "contributes": {}                // 通常为空
  }
}
```

### 混合插件配置（同时支持）
```json
{
  "name": "hybrid-plugin",
  "engines": { "vscode": "^1.84.0" },
  "main": "./extension.js",          // 普通插件入口
  "theiaPlugin": {
    "backend": "./backend.js",       // 后端入口
    "headless": "./headless.js"      // 无头入口（共享后端服务）
  },
  "activationEvents": ["*"],
  "headless": {
    "activationEvents": ["*"]
  }
}
```

---

## 五、API扩展机制

### 问题：无头插件如何获得API？

**答案：只能通过自定义API提供**

### 步骤 1：创建 API 提供者（Theia Extension）

```typescript
// packages/my-extension/src/node/my-api-provider.ts
import { injectable } from '@theia/core/shared/inversify';
import { ExtPluginApiProvider, ExtPluginApi } from '@theia/plugin-ext-headless';
import * as path from 'path';

@injectable()
export class MyApiProvider implements ExtPluginApiProvider {
    provideApi(): ExtPluginApi {
        return {
            // 为后端插件提供API
            backendInitPath: path.join(__dirname, 'my-api-init'),
            // 为无头插件提供API（可以是同一个）
            headlessInitPath: path.join(__dirname, 'my-api-init')
        };
    }
}
```

### 步骤 2：注册API提供者

```typescript
// packages/my-extension/src/node/backend-module.ts
import { ContainerModule } from 'inversify';

export default new ContainerModule(bind => {
    bind(MyApiProvider).toSelf().inSingletonScope();
    bind(Symbol.for(ExtPluginApiProvider)).toService(MyApiProvider);
});
```

### 步骤 3：实现API初始化脚本

```typescript
// packages/my-extension/src/plugin/my-api-init.ts
import { PluginContainerModule } from '@theia/plugin-ext/lib/plugin/node/plugin-container-module';

export const containerModule = PluginContainerModule.create(({ bind, bindApiFactory }) => {
    // 注册API工厂，插件通过 require('@my/api') 调用
    bindApiFactory('@my/api', MyApiFactory, MyApiFactoryImpl);
});

@injectable()
class MyApiFactoryImpl {
    createApi(plugin: Plugin) {
        return {
            // 你的API实现
            doSomething: async () => { ... },
            database: {
                query: async (sql) => { ... }
            }
        };
    }
}
```

### 步骤 4：在无头插件中使用

```javascript
// plugins/my-headless-plugin/headless.js
const myApi = require('@my/api');  // ✅ 可用

async function activate() {
    const result = await myApi.doSomething();
    const rows = await myApi.database.query('SELECT * FROM users');
}
```

### 官方示例

参考 `/root/theia/examples/api-provider-sample/` 目录：
- `src/node/ext-plugin-gotd-api-provider.ts` - API提供者
- `src/plugin/gotd-api-init.ts` - API初始化
- `/root/theia/sample-plugins/sample-namespace/plugin-gotd/` - 使用示例

---

## 六、如果无头插件使用UI API会怎样？

### 实验：尝试使用 vscode API

```javascript
// headless.js
function activate() {
    try {
        const vscode = require('vscode');
        console.log('vscode:', vscode);
    } catch (error) {
        console.error('Error:', error);
    }
}
```

### 结果分析

**情况1：vscode模块根本不存在**
```
Error: Cannot find module 'vscode'
```
原因：`createAPIFactory()` 返回 `null`，没有注册 vscode 模块

**情况2：即使强行注入vscode模块**
```javascript
const vscode = /* 假设somehow获取到了 */;
vscode.window.showInformationMessage('Hello');
```
结果：
- ❌ **运行时错误**：Main端在Node环境，没有浏览器的window对象
- ❌ **RPC失败**：没有连接到前端的RPC通道
- ❌ **上下文丢失**：没有前端连接上下文

### 为什么设计成这样？

1. **职责分离**：无头插件专注后端服务，不应关心UI
2. **性能考虑**：避免不必要的RPC开销
3. **架构清晰**：单一职责原则
4. **避免混淆**：防止开发者误用前端API

---

## 七、什么时候该用无头插件？

### ✅ 适合使用无头插件的场景

1. **共享后端资源**
   ```
   场景：数据库连接池、缓存连接
   原因：所有前端共享，避免重复创建连接
   ```

2. **全局单例服务**
   ```
   场景：许可证验证、用户会话管理
   原因：需要全局唯一的状态管理
   ```

3. **后台定时任务**
   ```
   场景：日志清理、数据同步、定时报告
   原因：不依赖前端连接，持续运行
   ```

4. **文件系统监控**
   ```
   场景：监控项目文件变化、代码生成
   原因：全局监控，不随前端打开/关闭
   ```

5. **CLI工具后端**
   ```
   场景：提供CLI命令的后端实现
   原因：独立于前端IDE
   ```

### ❌ 不适合使用无头插件的场景

1. **需要UI交互**
   ```
   场景：自定义编辑器、树视图、状态栏
   方案：使用普通插件
   ```

2. **前端特定功能**
   ```
   场景：语法高亮、代码补全
   方案：使用普通插件
   ```

3. **每个用户独立状态**
   ```
   场景：用户偏好设置、个人工作区状态
   方案：使用普通插件（per-frontend）
   ```

4. **需要丰富的激活事件**
   ```
   场景：onCommand, onLanguage 等
   方案：使用普通插件
   ```

---

## 八、实战示例对比

### 示例1：数据库连接池

**❌ 错误：使用普通插件**
```javascript
// 每个前端连接都会创建一个连接池 - 资源浪费！
function activate() {
    const pool = mysql.createPool({ ... });  // 多个实例
}
```

**✅ 正确：使用无头插件**
```javascript
// 只创建一次，所有前端共享
let pool = null;
function activate() {
    pool = mysql.createPool({ ... });  // 单例
    return { query: (sql) => pool.query(sql) };
}
```

### 示例2：状态栏扩展

**❌ 错误：使用无头插件**
```javascript
// 无头插件没有 vscode API！
function activate() {
    const vscode = require('vscode');  // Error!
    vscode.window.createStatusBarItem();  // 不可用
}
```

**✅ 正确：使用普通插件**
```javascript
const vscode = require('vscode');
function activate() {
    const item = vscode.window.createStatusBarItem();
    item.text = 'Hello';
    item.show();
}
```

---

## 九、调试技巧

### 检查插件类型
```javascript
function activate() {
    console.log('====== 插件类型检查 ======');

    // 检查 vscode API
    try {
        const vscode = require('vscode');
        console.log('✅ vscode API 可用');
    } catch (e) {
        console.log('❌ vscode API 不可用 - 这是无头插件');
    }

    // 检查进程信息
    console.log('进程ID:', process.pid);
    console.log('环境:', process.env.THEIA_HEADLESS_PLUGIN ? 'headless' : 'normal');

    // 检查是否单例
    global.__activationCount = (global.__activationCount || 0) + 1;
    console.log('激活次数:', global.__activationCount);
    // 如果打开多个前端，这个数字应该是1（无头）或递增（普通）
}
```

---

## 十、总结

### 核心要点

1. **无头插件 = 后端单例 + 零UI + 无默认API**
2. **只能通过自定义API扩展功能**（需要写Theia Extension）
3. **适合共享后端服务，不适合UI扩展**
4. **不能用 vscode/theia API，用了会报错**

### 决策树

```
需要UI扩展？
├─ 是 → 普通插件
└─ 否 → 需要多个前端共享状态？
         ├─ 是 → 无头插件 ✅
         └─ 否 → 普通插件
```

### 最佳实践

1. **明确职责**：无头插件只做后端服务
2. **提供API**：通过自定义API暴露功能给其他插件
3. **资源管理**：在 `deactivate()` 中清理所有资源
4. **错误处理**：后端错误不会显示给用户，需要完善日志
5. **文档化**：清晰说明提供的API和使用方法
