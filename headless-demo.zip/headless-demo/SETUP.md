# Headless Demo Plugin - 配置指南

## 方法一：直接放在 plugins 目录（推荐）

插件已经在正确的位置了：`/root/theia/plugins/headless-demo/`

### 步骤

1. **确认插件位置**
   ```bash
   ls /root/theia/plugins/headless-demo/
   # 应该看到: package.json, headless.js, README.md
   ```

2. **重启 Theia 应用**
   ```bash
   # 停止当前运行的 Theia
   # 然后重新启动
   yarn start
   ```

3. **查看日志确认加载**
   启动后查看控制台，应该看到：
   ```
   ========================================
   [Headless Demo] 插件已激活
   [Headless Demo] 这是一个无头插件示例
   [Headless Demo] 激活次数: 1
   ...
   ========================================
   ```

## 方法二：通过环境变量指定插件目录

如果想从其他位置加载插件：

```bash
export THEIA_DEFAULT_PLUGINS="local-dir:/path/to/plugins"
yarn start
```

## 方法三：在 package.json 中配置

编辑应用的 `package.json`（通常在 `examples/browser/package.json` 或 `examples/electron/package.json`）：

```json
{
  "theia": {
    "frontend": {
      "config": {
        "defaultPlugins": "local-dir:../../plugins"
      }
    }
  }
}
```

## 验证插件是否正确加载

### 1. 检查插件列表

在 Theia IDE 中：
- 打开命令面板（Ctrl/Cmd + Shift + P）
- 输入 "Plugins"
- 查看是否有 "Headless Demo Plugin"

### 2. 查看后端日志

```bash
# 在启动 Theia 的终端中查看日志
# 应该能看到 [Headless Demo] 的输出
```

### 3. 测试单例特性

1. 在浏览器中打开第一个 Theia 实例
   - 查看日志：`[Headless Demo] 激活次数: 1`

2. 在新标签页/窗口中打开第二个 Theia 实例
   - 观察：不会再次输出激活日志
   - 两个前端共享同一个插件实例

3. 观察定时器输出
   - 每 30 秒会输出一次状态
   - 显示当前运行时长和连接的客户端数

## 常见问题

### Q1: 插件没有加载？

**检查清单：**
- [ ] `package.json` 中 `theiaPlugin.headless` 配置正确
- [ ] `headless.js` 文件存在且可读
- [ ] 插件目录在 Theia 的插件搜索路径中
- [ ] 已重启 Theia 应用

### Q2: 如何确认是无头插件而不是普通插件？

无头插件的特征：
- ✅ 只有 `headless.js`，没有 UI 相关代码
- ✅ `package.json` 中有 `headless` 配置节
- ✅ 无论打开多少个前端，只激活一次

### Q3: 如何调试无头插件？

1. 在 `headless.js` 中添加 `console.log` 语句
2. 查看 Theia 后端进程的控制台输出
3. 使用 Node.js 调试器附加到后端进程

### Q4: 插件报错怎么办？

1. 检查 `headless.js` 的语法
   ```bash
   node --check /root/theia/plugins/headless-demo/headless.js
   ```

2. 查看完整的错误堆栈
   ```bash
   # 启动 Theia 时查看完整日志
   yarn start 2>&1 | grep -A 10 "Headless Demo"
   ```

## 配置插件目录的其他方式

### 通过启动参数

```bash
yarn theia start --plugins=local-dir:./plugins
```

### 通过配置文件

创建 `.theia/settings.json`：
```json
{
  "plugin.paths": [
    "./plugins"
  ]
}
```

## 开发模式

如果正在开发插件，可以使用符号链接：

```bash
# 在 Theia 的插件目录中创建符号链接
ln -s /path/to/your/plugin /root/theia/plugins/your-plugin
```

## 生产部署

### 1. 打包插件

```bash
cd /root/theia/plugins/headless-demo
npm pack
# 或
yarn pack
```

这会生成 `headless-demo-1.0.0.tgz` 文件

### 2. 部署到生产环境

将 `.tgz` 文件复制到生产环境的 plugins 目录：

```bash
cp headless-demo-1.0.0.tgz /production/theia/plugins/
cd /production/theia/plugins/
tar -xzf headless-demo-1.0.0.tgz
```

## 下一步

- 📖 阅读 [README.md](./README.md) 了解插件功能
- 🔧 修改 `headless.js` 实现自己的后端服务
- 📚 查看 [Theia Plugin API 文档](../../doc/Plugin-API.md)
- 🎯 参考官方示例 [plugin-gotd](../../sample-plugins/sample-namespace/plugin-gotd/)

## 需要帮助？

- [Theia 官方文档](https://theia-ide.org/docs/)
- [Theia GitHub Issues](https://github.com/eclipse-theia/theia/issues)
- [Theia Discourse 论坛](https://discourse.theia-ide.org/)
