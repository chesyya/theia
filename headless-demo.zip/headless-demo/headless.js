// *****************************************************************************
// Headless Demo Plugin
//
// This is a headless plugin example that demonstrates:
// 1. Running only once on the backend (not per-frontend)
// 2. Using the @theia/headless-service API extension
// 3. Shared global state across all frontend instances
// 4. Scheduled tasks and event handling
// *****************************************************************************

// Import the headless service API
// This API is provided by plugin-ext-headless and allows access to:
// - System information
// - Global state management
// - Scheduled tasks
// - Logging via main process
let headlessService;
try {
    headlessService = require('@theia/headless-service');
} catch (e) {
    console.log('[Headless Demo] @theia/headless-service not available, using fallback mode');
    headlessService = null;
}

// Global state
let activationCount = 0;
let startTime = null;
const connectedClients = new Set();
const disposables = [];

/**
 * Plugin activation function - called only once for the entire backend instance
 */
async function activate() {
    activationCount++;
    startTime = new Date();

    console.log('========================================');
    console.log('[Headless Demo] Plugin activated');
    console.log('[Headless Demo] This is a headless plugin example');
    console.log('[Headless Demo] Activation count:', activationCount);
    console.log('[Headless Demo] Activation time:', startTime.toISOString());
    console.log('[Headless Demo] Important: This plugin loads only ONCE regardless of how many frontends connect!');
    console.log('========================================');

    // If headless service API is available, use it
    if (headlessService) {
        await initializeWithHeadlessService();
    } else {
        await initializeWithFallback();
    }

    console.log('[Headless Demo] Initialization complete');
}

/**
 * Initialize using the @theia/headless-service API
 */
async function initializeWithHeadlessService() {
    console.log('[Headless Demo] Using @theia/headless-service API');

    // 1. Get and display system information
    try {
        const sysInfo = await headlessService.getSystemInfo();
        console.log('[Headless Demo] System Information:');
        console.log(`  - Platform: ${sysInfo.platform}`);
        console.log(`  - Node.js: ${sysInfo.nodeVersion}`);
        console.log(`  - CPUs: ${sysInfo.cpuCount}`);
        console.log(`  - Memory: ${formatBytes(sysInfo.memoryUsage.used)} / ${formatBytes(sysInfo.memoryUsage.total)}`);
        console.log(`  - Uptime: ${formatDuration(sysInfo.uptime)}`);
    } catch (e) {
        console.error('[Headless Demo] Failed to get system info:', e.message);
    }

    // 2. Set initial global state
    try {
        await headlessService.setGlobalState('headless-demo:startTime', startTime.toISOString());
        await headlessService.setGlobalState('headless-demo:activationCount', activationCount);
        console.log('[Headless Demo] Global state initialized');
    } catch (e) {
        console.error('[Headless Demo] Failed to set global state:', e.message);
    }

    // 3. Listen for global state changes
    try {
        const stateDisposable = headlessService.onGlobalStateChanged((event) => {
            if (event.key.startsWith('headless-demo:')) {
                console.log(`[Headless Demo] State changed: ${event.key} = ${JSON.stringify(event.value)}`);
            }
        });
        disposables.push(stateDisposable);
    } catch (e) {
        console.error('[Headless Demo] Failed to listen for state changes:', e.message);
    }

    // 4. Schedule periodic status report
    try {
        await headlessService.scheduleTask('headless-demo:status', 30000, async () => {
            const uptime = Math.floor((Date.now() - startTime.getTime()) / 1000);
            const sysInfo = await headlessService.getSystemInfo();

            await headlessService.log('info',
                `Status Report - Uptime: ${formatDuration(uptime)}, ` +
                `Memory: ${formatBytes(sysInfo.memoryUsage.used)} / ${formatBytes(sysInfo.memoryUsage.total)}, ` +
                `Clients: ${connectedClients.size}`
            );

            // Reschedule the task (it's a one-time task, so we need to reschedule)
            await headlessService.scheduleTask('headless-demo:status', 30000, arguments.callee);
        });
        console.log('[Headless Demo] Status reporting task scheduled (every 30 seconds)');
    } catch (e) {
        console.error('[Headless Demo] Failed to schedule status task:', e.message);
    }

    // 5. Listen for task triggers
    try {
        const taskDisposable = headlessService.onTaskTriggered((taskId) => {
            if (taskId.startsWith('headless-demo:')) {
                console.log(`[Headless Demo] Task triggered: ${taskId}`);
            }
        });
        disposables.push(taskDisposable);
    } catch (e) {
        console.error('[Headless Demo] Failed to listen for tasks:', e.message);
    }

    // 6. Log via main process
    try {
        await headlessService.log('info', 'Headless Demo plugin initialized successfully');
    } catch (e) {
        console.error('[Headless Demo] Failed to log via main process:', e.message);
    }
}

/**
 * Initialize with fallback mode (when headless service is not available)
 */
async function initializeWithFallback() {
    console.log('[Headless Demo] Using fallback mode (no headless service API)');

    // Simple fallback using setInterval
    const statusTimer = setInterval(() => {
        const uptime = Math.floor((Date.now() - startTime.getTime()) / 1000);
        console.log(`[Headless Demo] Status - Uptime: ${formatDuration(uptime)}, Clients: ${connectedClients.size}`);
    }, 30000);

    disposables.push({ dispose: () => clearInterval(statusTimer) });

    // Simulate async initialization
    await simulateAsyncInit();
}

/**
 * Simulate async initialization tasks
 */
async function simulateAsyncInit() {
    console.log('[Headless Demo] Initializing backend services...');

    await delay(1000);
    console.log('[Headless Demo] Database connection pool initialized');

    await delay(1000);
    console.log('[Headless Demo] Cache service started');

    await delay(1000);
    console.log('[Headless Demo] Background task scheduler started');
}

/**
 * Register a client connection
 */
function registerClient(clientId) {
    connectedClients.add(clientId);
    console.log(`[Headless Demo] Client connected: ${clientId}, Total: ${connectedClients.size}`);

    if (headlessService) {
        headlessService.setGlobalState('headless-demo:clientCount', connectedClients.size)
            .catch(e => console.error('[Headless Demo] Failed to update client count:', e.message));
    }
}

/**
 * Unregister a client connection
 */
function unregisterClient(clientId) {
    connectedClients.delete(clientId);
    console.log(`[Headless Demo] Client disconnected: ${clientId}, Total: ${connectedClients.size}`);

    if (headlessService) {
        headlessService.setGlobalState('headless-demo:clientCount', connectedClients.size)
            .catch(e => console.error('[Headless Demo] Failed to update client count:', e.message));
    }
}

/**
 * Plugin deactivation function - cleanup resources
 */
async function deactivate() {
    console.log('========================================');
    console.log('[Headless Demo] Plugin deactivating...');

    // Cancel scheduled tasks
    if (headlessService) {
        try {
            await headlessService.cancelTask('headless-demo:status');
            console.log('[Headless Demo] Scheduled tasks cancelled');
        } catch (e) {
            console.error('[Headless Demo] Failed to cancel tasks:', e.message);
        }
    }

    // Dispose all listeners
    for (const disposable of disposables) {
        try {
            disposable.dispose();
        } catch (e) {
            // Ignore disposal errors
        }
    }
    disposables.length = 0;

    // Clean up client connections
    connectedClients.clear();

    const uptime = startTime ? Math.floor((Date.now() - startTime.getTime()) / 1000) : 0;
    console.log(`[Headless Demo] Total runtime: ${formatDuration(uptime)}`);
    console.log('[Headless Demo] Plugin deactivated');
    console.log('========================================');
}

// ========== Utility Functions ==========

function formatBytes(bytes) {
    const units = ['B', 'KB', 'MB', 'GB'];
    let unitIndex = 0;
    let value = bytes;

    while (value >= 1024 && unitIndex < units.length - 1) {
        value /= 1024;
        unitIndex++;
    }

    return `${value.toFixed(1)} ${units[unitIndex]}`;
}

function formatDuration(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hours > 0) {
        return `${hours}h ${minutes}m ${secs}s`;
    } else if (minutes > 0) {
        return `${minutes}m ${secs}s`;
    } else {
        return `${secs}s`;
    }
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Export plugin interface
module.exports = {
    activate,
    deactivate
};
