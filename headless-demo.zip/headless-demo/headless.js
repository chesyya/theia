// *****************************************************************************
// Headless Demo Plugin
//
// This is a headless plugin example that demonstrates:
// 1. Running only once on the backend (not per-frontend)
// 2. Shared state across all frontend instances
// 3. Backend-only services
// *****************************************************************************

// 全局状态 - 所有前端共享
let activationCount = 0;
let startTime = null;
const connectedClients = new Set();

// 定时器引用
let statusTimer = null;

/**
 * 插件激活函数 - 整个后端实例只会调用一次
 */
async function activate() {
    activationCount++;
    startTime = new Date();

    console.log('========================================');
    console.log('[Headless Demo] 插件已激活');
    console.log('[Headless Demo] 这是一个无头插件示例');
    console.log('[Headless Demo] 激活次数:', activationCount);
    console.log('[Headless Demo] 激活时间:', startTime.toISOString());
    console.log('[Headless Demo] 🎯 重要: 无论启动多少个前端，此插件只会加载一次！');
    console.log('========================================');

    // 模拟后端服务 - 定期输出状态
    statusTimer = setInterval(() => {
        const uptime = Math.floor((Date.now() - startTime.getTime()) / 1000);
        console.log(`[Headless Demo] 运行状态 - 运行时长: ${uptime}秒, 连接的客户端: ${connectedClients.size}`);
    }, 30000); // 每30秒输出一次

    // 模拟一些后端任务
    initializeBackendServices();

    console.log('[Headless Demo] 初始化完成 ✓');
}

/**
 * 初始化后端服务
 */
function initializeBackendServices() {
    console.log('[Headless Demo] 初始化后端服务...');

    // 示例：可以在这里初始化
    // - 数据库连接池
    // - 缓存服务
    // - 消息队列
    // - 定时任务
    // - 文件监控
    // 等只需要在后端运行一次的服务

    // 模拟异步初始化
    setTimeout(() => {
        console.log('[Headless Demo] ✓ 数据库连接池已初始化');
    }, 1000);

    setTimeout(() => {
        console.log('[Headless Demo] ✓ 缓存服务已启动');
    }, 2000);

    setTimeout(() => {
        console.log('[Headless Demo] ✓ 后台任务调度器已启动');
    }, 3000);
}

/**
 * 注册新客户端连接（示例函数）
 */
function registerClient(clientId) {
    connectedClients.add(clientId);
    console.log(`[Headless Demo] 新客户端连接: ${clientId}, 当前总数: ${connectedClients.size}`);
}

/**
 * 注销客户端连接（示例函数）
 */
function unregisterClient(clientId) {
    connectedClients.delete(clientId);
    console.log(`[Headless Demo] 客户端断开: ${clientId}, 当前总数: ${connectedClients.size}`);
}

/**
 * 插件停用函数 - 清理资源
 */
function deactivate() {
    console.log('========================================');
    console.log('[Headless Demo] 插件正在停用...');

    // 清理定时器
    if (statusTimer) {
        clearInterval(statusTimer);
        statusTimer = null;
        console.log('[Headless Demo] ✓ 状态定时器已清理');
    }

    // 清理客户端连接
    connectedClients.clear();
    console.log('[Headless Demo] ✓ 客户端连接已清理');

    const uptime = startTime ? Math.floor((Date.now() - startTime.getTime()) / 1000) : 0;
    console.log(`[Headless Demo] 总运行时长: ${uptime}秒`);
    console.log('[Headless Demo] 插件已停用');
    console.log('========================================');
}

// 导出插件接口
module.exports = {
    activate,
    deactivate
};
