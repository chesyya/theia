/**
 * Plugin activation function - called only once for the entire backend instance
 */
export declare function activate(): Promise<void>;
/**
 * Register a client connection
 */
export declare function registerClient(clientId: string): void;
/**
 * Unregister a client connection
 */
export declare function unregisterClient(clientId: string): void;
/**
 * Plugin deactivation function - cleanup resources
 */
export declare function deactivate(): Promise<void>;
