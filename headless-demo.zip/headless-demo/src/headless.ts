// *****************************************************************************
// Headless Demo Plugin (TypeScript)
//
// This is a headless plugin example that demonstrates:
// 1. Running only once on the backend (not per-frontend)
// 2. Using the @theia/headless-service API extension
// 3. Shared global state across all frontend instances
// 4. Scheduled tasks and event handling
// *****************************************************************************

import type { Disposable, SystemInfo, GlobalStateChangeEvent } from '@theia/headless-service';

// Headless service API interface
interface HeadlessServiceAPI {
    getSystemInfo(): Promise<SystemInfo>;
    setGlobalState(key: string, value: unknown): Promise<void>;
    getGlobalState<T = unknown>(key: string): Promise<T | undefined>;
    log(level: 'info' | 'warn' | 'error', message: string): Promise<void>;
    scheduleTask(taskId: string, delayMs: number, callback?: () => void | Promise<void>): Promise<void>;
    cancelTask(taskId: string): Promise<boolean>;
    onTaskTriggered(listener: (taskId: string) => void): Disposable;
    onGlobalStateChanged(listener: (event: GlobalStateChangeEvent) => void): Disposable;
}

// Import the headless service API
let headlessService: HeadlessServiceAPI | null = null;
try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    headlessService = require('@theia/headless-service') as HeadlessServiceAPI;
} catch (e) {
    console.log('[Headless Demo] @theia/headless-service not available, using fallback mode');
}

// Global state
let activationCount = 0;
let startTime: Date | null = null;
const connectedClients = new Set<string>();
const disposables: Disposable[] = [];

/**
 * Plugin activation function - called only once for the entire backend instance
 */
export async function activate(): Promise<void> {
    activationCount++;
    startTime = new Date();

    console.log('========================================');
    console.log('[Headless Demo] Plugin activated');
    console.log('[Headless Demo] This is a headless plugin example');
    console.log('[Headless Demo] Activation count:', activationCount);
    console.log('[Headless Demo] Activation time:', startTime.toISOString());
    console.log('[Headless Demo] Important: This plugin loads only ONCE regardless of how many frontends connect!');
    console.log('========================================');

    // If headless service API is available, use it
    if (headlessService) {
        await initializeWithHeadlessService(headlessService);
    } else {
        await initializeWithFallback();
    }

    console.log('[Headless Demo] Initialization complete');
}

/**
 * Initialize using the @theia/headless-service API
 */
async function initializeWithHeadlessService(service: HeadlessServiceAPI): Promise<void> {
    console.log('[Headless Demo] Using @theia/headless-service API');

    // 1. Get and display system information
    try {
        const sysInfo = await service.getSystemInfo();
        console.log('[Headless Demo] System Information:');
        console.log(`  - Platform: ${sysInfo.platform}`);
        console.log(`  - Node.js: ${sysInfo.nodeVersion}`);
        console.log(`  - CPUs: ${sysInfo.cpuCount}`);
        console.log(`  - Memory: ${formatBytes(sysInfo.memoryUsage.used)} / ${formatBytes(sysInfo.memoryUsage.total)}`);
        console.log(`  - Uptime: ${formatDuration(sysInfo.uptime)}`);
    } catch (e) {
        const error = e as Error;
        console.error('[Headless Demo] Failed to get system info:', error.message);
    }

    // 2. Set initial global state
    try {
        await service.setGlobalState('headless-demo:startTime', startTime!.toISOString());
        await service.setGlobalState('headless-demo:activationCount', activationCount);
        console.log('[Headless Demo] Global state initialized');
    } catch (e) {
        const error = e as Error;
        console.error('[Headless Demo] Failed to set global state:', error.message);
    }

    // 3. Listen for global state changes
    try {
        const stateDisposable = service.onGlobalStateChanged((event: GlobalStateChangeEvent) => {
            if (event.key.startsWith('headless-demo:')) {
                console.log(`[Headless Demo] State changed: ${event.key} = ${JSON.stringify(event.value)}`);
            }
        });
        disposables.push(stateDisposable);
    } catch (e) {
        const error = e as Error;
        console.error('[Headless Demo] Failed to listen for state changes:', error.message);
    }

    // 4. Schedule periodic status report
    try {
        const scheduleStatusReport = async (): Promise<void> => {
            const uptime = Math.floor((Date.now() - startTime!.getTime()) / 1000);
            const sysInfo = await service.getSystemInfo();

            await service.log('info',
                `Status Report - Uptime: ${formatDuration(uptime)}, ` +
                `Memory: ${formatBytes(sysInfo.memoryUsage.used)} / ${formatBytes(sysInfo.memoryUsage.total)}, ` +
                `Clients: ${connectedClients.size}`
            );

            // Reschedule the task
            await service.scheduleTask('headless-demo:status', 30000, scheduleStatusReport);
        };

        await service.scheduleTask('headless-demo:status', 30000, scheduleStatusReport);
        console.log('[Headless Demo] Status reporting task scheduled (every 30 seconds)');
    } catch (e) {
        const error = e as Error;
        console.error('[Headless Demo] Failed to schedule status task:', error.message);
    }

    // 5. Listen for task triggers
    try {
        const taskDisposable = service.onTaskTriggered((taskId: string) => {
            if (taskId.startsWith('headless-demo:')) {
                console.log(`[Headless Demo] Task triggered: ${taskId}`);
            }
        });
        disposables.push(taskDisposable);
    } catch (e) {
        const error = e as Error;
        console.error('[Headless Demo] Failed to listen for tasks:', error.message);
    }

    // 6. Log via main process
    try {
        await service.log('info', 'Headless Demo plugin initialized successfully');
    } catch (e) {
        const error = e as Error;
        console.error('[Headless Demo] Failed to log via main process:', error.message);
    }
}

/**
 * Initialize with fallback mode (when headless service is not available)
 */
async function initializeWithFallback(): Promise<void> {
    console.log('[Headless Demo] Using fallback mode (no headless service API)');

    // Simple fallback using setInterval
    const statusTimer = setInterval(() => {
        const uptime = Math.floor((Date.now() - startTime!.getTime()) / 1000);
        console.log(`[Headless Demo] Status - Uptime: ${formatDuration(uptime)}, Clients: ${connectedClients.size}`);
    }, 30000);

    disposables.push({ dispose: () => clearInterval(statusTimer) });

    // Simulate async initialization
    await simulateAsyncInit();
}

/**
 * Simulate async initialization tasks
 */
async function simulateAsyncInit(): Promise<void> {
    console.log('[Headless Demo] Initializing backend services...');

    await delay(1000);
    console.log('[Headless Demo] Database connection pool initialized');

    await delay(1000);
    console.log('[Headless Demo] Cache service started');

    await delay(1000);
    console.log('[Headless Demo] Background task scheduler started');
}

/**
 * Register a client connection
 */
export function registerClient(clientId: string): void {
    connectedClients.add(clientId);
    console.log(`[Headless Demo] Client connected: ${clientId}, Total: ${connectedClients.size}`);

    if (headlessService) {
        headlessService.setGlobalState('headless-demo:clientCount', connectedClients.size)
            .catch((e: Error) => console.error('[Headless Demo] Failed to update client count:', e.message));
    }
}

/**
 * Unregister a client connection
 */
export function unregisterClient(clientId: string): void {
    connectedClients.delete(clientId);
    console.log(`[Headless Demo] Client disconnected: ${clientId}, Total: ${connectedClients.size}`);

    if (headlessService) {
        headlessService.setGlobalState('headless-demo:clientCount', connectedClients.size)
            .catch((e: Error) => console.error('[Headless Demo] Failed to update client count:', e.message));
    }
}

/**
 * Plugin deactivation function - cleanup resources
 */
export async function deactivate(): Promise<void> {
    console.log('========================================');
    console.log('[Headless Demo] Plugin deactivating...');

    // Cancel scheduled tasks
    if (headlessService) {
        try {
            await headlessService.cancelTask('headless-demo:status');
            console.log('[Headless Demo] Scheduled tasks cancelled');
        } catch (e) {
            const error = e as Error;
            console.error('[Headless Demo] Failed to cancel tasks:', error.message);
        }
    }

    // Dispose all listeners
    for (const disposable of disposables) {
        try {
            disposable.dispose();
        } catch {
            // Ignore disposal errors
        }
    }
    disposables.length = 0;

    // Clean up client connections
    connectedClients.clear();

    const uptime = startTime ? Math.floor((Date.now() - startTime.getTime()) / 1000) : 0;
    console.log(`[Headless Demo] Total runtime: ${formatDuration(uptime)}`);
    console.log('[Headless Demo] Plugin deactivated');
    console.log('========================================');
}

// ========== Utility Functions ==========

function formatBytes(bytes: number): string {
    const units = ['B', 'KB', 'MB', 'GB'];
    let unitIndex = 0;
    let value = bytes;

    while (value >= 1024 && unitIndex < units.length - 1) {
        value /= 1024;
        unitIndex++;
    }

    return `${value.toFixed(1)} ${units[unitIndex]}`;
}

function formatDuration(seconds: number): string {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hours > 0) {
        return `${hours}h ${minutes}m ${secs}s`;
    } else if (minutes > 0) {
        return `${minutes}m ${secs}s`;
    } else {
        return `${secs}s`;
    }
}

function delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
}
