# Headless Demo Plugin

这是一个**无头插件（Headless Plugin）**示例，演示了如何创建一个只在后端运行一次的插件。

## 什么是无头插件？

无头插件是 Theia 中的一种特殊插件类型：

- ✅ **只有后端代码**，没有前端UI
- ✅ **单例模式**：整个 Theia 后端实例只加载一次
- ✅ **所有前端共享**：无论启动多少个前端IDE，都使用同一个插件实例
- ✅ **适合后端服务**：数据库连接池、缓存、定时任务等

## 与普通插件的区别

| 特性 | 普通插件 | 无头插件 |
|------|---------|---------|
| 加载次数 | 每个前端连接加载一次 | 整个后端只加载一次 |
| 运行环境 | 前端 + 后端 | 仅后端 |
| UI扩展 | ✅ 支持 | ❌ 不支持 |
| 共享状态 | 每个前端独立 | 所有前端共享 |
| 适用场景 | UI扩展、编辑器功能 | 后端服务、资源池 |

## 插件结构

```
headless-demo/
├── package.json      # 插件配置文件
├── headless.js       # 无头插件入口文件
└── README.md         # 说明文档
```

## package.json 关键配置

```json
{
  "theiaPlugin": {
    "headless": "headless"  // 指定无头插件入口文件
  },
  "headless": {
    "activationEvents": [
      "*"  // 启动时自动激活
    ],
    "contributes": {}
  }
}
```

### 配置说明

1. **`theiaPlugin.headless`**：指向无头插件的入口文件（不带 .js 扩展名）
2. **`headless.activationEvents`**：定义插件激活时机
   - `"*"`: 启动时立即激活
   - `"onStartupFinished"`: 启动完成后激活
3. **`headless.contributes`**：贡献点配置（通常为空，因为无头插件不扩展UI）

## headless.js 入口文件

插件必须导出两个函数：

```javascript
module.exports = {
    activate,    // 插件激活时调用（只调用一次）
    deactivate   // 插件停用时调用（清理资源）
};
```

### activate() 函数

- 在整个后端实例中**只调用一次**
- 适合初始化后端服务、建立连接池等
- 可以设置定时任务、监听器等

### deactivate() 函数

- 插件停用时调用
- 用于清理资源：关闭连接、清除定时器等

## 使用场景

无头插件适合以下场景：

1. **数据库连接池**：多个前端共享同一个连接池
2. **缓存服务**：Redis/Memcached 等缓存连接
3. **后台定时任务**：定期清理、数据同步等
4. **文件监控服务**：监控文件系统变化
5. **消息队列**：RabbitMQ、Kafka 等消息服务
6. **WebSocket 服务器**：全局的 WebSocket 连接管理
7. **日志聚合**：集中式日志收集
8. **许可证管理**：全局的许可证验证服务

## 如何部署

1. 将插件目录放到 Theia 的 `plugins` 目录下
2. 重启 Theia 应用
3. 查看控制台日志，确认插件已激活

## 验证效果

1. 启动第一个前端IDE，查看日志输出 `[Headless Demo] 激活次数: 1`
2. 启动第二个前端IDE，观察：
   - ❌ 不会再次输出激活日志
   - ✅ 两个前端共享同一个插件实例
   - ✅ 定时器、状态等都是共享的

## 日志示例

```
========================================
[Headless Demo] 插件已激活
[Headless Demo] 这是一个无头插件示例
[Headless Demo] 激活次数: 1
[Headless Demo] 激活时间: 2026-01-12T10:30:00.000Z
[Headless Demo] 🎯 重要: 无论启动多少个前端，此插件只会加载一次！
========================================
[Headless Demo] 初始化后端服务...
[Headless Demo] ✓ 数据库连接池已初始化
[Headless Demo] ✓ 缓存服务已启动
[Headless Demo] ✓ 后台任务调度器已启动
[Headless Demo] 初始化完成 ✓
[Headless Demo] 运行状态 - 运行时长: 30秒, 连接的客户端: 2
```

## 注意事项

1. **无法使用 vscode API**：无头插件运行在纯后端环境，无法访问 UI 相关的 vscode API
2. **需要自定义 API**：如果需要与前端通信，需要通过自定义 API 实现
3. **生命周期管理**：确保在 `deactivate()` 中正确清理所有资源
4. **错误处理**：后端错误不会直接显示给用户，需要合理的日志记录

## 扩展阅读

- [Theia Plugin API 文档](../../doc/Plugin-API.md)
- [plugin-ext-headless 包](../../packages/plugin-ext-headless/)
- [官方示例：plugin-gotd](../../sample-plugins/sample-namespace/plugin-gotd/)

## License

EPL-2.0 OR GPL-2.0-only WITH Classpath-exception-2.0
